import os
import socket
import struct
import sys
import time

if os.name == 'nt': os.system("cls")
else: os.system("clear")

# Connect as a TAS client
HOST = "127.0.0.1"
PORT = 6555
sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
try: sock.connect((HOST, PORT))
except ConnectionRefusedError: 
	print("Connection refused! This likely means `sar_tas_server` is 0 or the game is not open.")
	print("It can also mean there is an issue with the socket binding process.")
	print("Check if the TAS server successfully started.")
	sys.exit()
sock.setblocking(False)

gamedir = "unknown"

# Send message to SAR
def send_message(type: str, data: any):
	packet = b''
	more = b''
	typeI = -1
	if (type == "play"):
		typeI = 0
		more = struct.pack("!I", len(data[0]))
		more += data[0].encode()
		string = ""
		if (len(data) == 2):
			more += struct.pack("!I", len(data[1]))
			more += data[1].encode()
			string = " & " + data[1]
		else:
			more += struct.pack("!I", 0) # SP tas
		print("Play - " + data[0] + string)

	if (type == "stop"):
		typeI = 1
		print("Stop")

	if (type == "speed"):
		typeI = 2
		more = struct.pack("!f", float(data))
		print("SetPlaybackRate = " + data)

	if (type == "unpause"):
		typeI = 3
		print("Unpause")

	if (type == "pause"):
		typeI = 4
		print("Pause")

	if (type == "fastforward" or type == "ffwd" or type == "skip" or type == "skipto"):
		typeI = 5
		if len(data) != 2:
			data.append("0")
		more = struct.pack("!I", int(data[0]))
		more += struct.pack("!B", int(data[1]))
		string = ""
		if data[1] == "0": string = "NOT "
		print("SkipTo " + data[0] + ", " + string + "pausing after")

	if (type == "pauseat"):
		typeI = 6
		more += struct.pack("!I", int(data))
		print("SetPauseAtTick = ", data)

	if (type == "advance"):
		typeI = 7
		print("AdvanceTick")

	if (type == "playtxt"):
		typeI = 10
		more = struct.pack("!I", len(data[0]))
		more += data[0].encode()
		more += struct.pack("!I", len(data[1]))
		more += data[1].encode()
		more += struct.pack("!I", len(data[2]))
		more += data[2].encode()
		more += struct.pack("!I", len(data[3]))
		more += data[3].encode()
		print("PlayTextScript")

	if (type == "entity"):
		typeI = 100
		print("EntityRequest - " + data)
		more = struct.pack("!I", len(data))
		more += data.encode()

	if typeI == -1: 
		print("ERR: Unknown user message type \"" + type + "\"!")
		return
	packet += struct.pack("!B", typeI)
	packet += more
	# print("INFO: Send: " + str(packet))
	sock.send(packet)

# Receive message from SAR
def recv_message():
	# Read messages until there is no message to read
	while True:
		try: typeMsg = sock.recv(1)
		except BlockingIOError: return
		if not typeMsg: return
		typeI = struct.unpack("!B", typeMsg)[0]
		type = ""
		if (typeI == 0):
			type = "setactive"
			len1 = struct.unpack("!I", sock.recv(4))[0]
			filename1 = struct.unpack("!"+str(len1)+"s", sock.recv(len1))[0].decode()
			len2 = struct.unpack("!I", sock.recv(4))[0]
			filename2 = ""
			string = ""
			if (len2 != 0):
				filename2 = struct.unpack("!"+str(len2)+"s", sock.recv(len2))[0].decode()
				string = ", " + filename2
			print("SetActive - " + filename1 + string)

		if (typeI == 1):
			type = "setinactive"
			print("SetInactive")

		if (typeI == 2):
			type = "speed"
			rate = struct.unpack("!f", sock.recv(4))[0]
			print("PlaybackRate - " + str(rate))

		if (typeI == 3):
			type = "playing"
			print("State = Playing")

		if (typeI == 4):
			type = "paused"
			print("State = Paused")

		if (typeI == 5):
			type = "fastforward"
			print("State = FFWD")

		if (typeI == 6):
			type = "currenttick"
			tick = struct.unpack("!I", sock.recv(4))[0]
			# print("CurrentTick is " + str(tick))

		if (typeI == 7):
			type = "debugtick"
			tick = struct.unpack("!i", sock.recv(4))[0]
			# print("DebugTick is " + str(tick))

		if (typeI == 10):
			type = "processedscript"
			slot = struct.unpack("!B", sock.recv(1))[0]
			lenscript = struct.unpack("!I", sock.recv(4))[0]
			script = struct.unpack("!"+str(lenscript)+"s", sock.recv(lenscript))[0].decode()
			# print("RawScript - Slot" + str(slot) + ":\n" + script)

		if (typeI == 100):
			type = "entity"
			success = struct.unpack("!B", sock.recv(1))[0]
			if (success == 1):
				position = [
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0]
				]
				angles = [
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0]
				]
				velocity = [
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0],
					struct.unpack("!f", sock.recv(4))[0]
				]
				print("EntityResponse")
				print("\t" + str(position))
				print("\t" + str(angles))
				print("\t" + str(velocity))

		if (typeI == 255):
			type = "gameloc"
			lenloc = struct.unpack("!I", sock.recv(4))[0]
			gamedir = struct.unpack("!"+str(lenloc)+"s", sock.recv(lenloc))[0].decode()
			print("GameLocation = " + gamedir)

		if (type == ""):
			print("ERR: Unknown SAR message type " + str(typeI) + "!")

while True:
	recv_message()
	undo = 0
	done = 0
	type = ""
	data = ""
	do = "0"
	with open("instruction.txt", "r") as f:
		lines = f.read().split('\n')
		if (len(lines) > 2):
			type = lines[0]
			data = lines[1]
			do = lines[2]
		if (do == "1"):
			undo = 1
			sData = data
			if (type == "play" or type == "fastforward" or type == "ffwd" or type == "skip" or type == "skipto" or type == "playtxt"): sData = sData.split(",")
			if (type == "playtxt"):
				if (len(sData) > 1):
					with open(sData[1], "r") as file:
						sData[1] = file.read()
					if (len(sData) > 2):
						with open(sData[3], "r") as file:
							sData[3] = file.read()
				else:
					print("Syntax <scriptname>,<path>[,<scriptname>,<path>]. Path is relative to tasserver.py")
				while len(sData) < 4: sData.append("")
			if (type == "done"):
				done = 1
			else:
				send_message(type, sData)

	# Reset 1 to 0 in instruction so it's not repeatedly sent
	if (undo == 1):
		with open("instruction.txt", "w") as f: f.write('\n'.join([type, data, "0"]) + '\n')

	if (done == 1): break
	time.sleep(0.1)

sock.close()
