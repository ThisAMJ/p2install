Simply run `python tasserver.py` to setup the server.

This server is now exclusive to the changes proposed by #154. The server for previous versions of SAR can be found in old.zip.

To send a message to SAR, open instruction.txt and put one of the following on the first line:
 - play
    - <chell/atlas path from .../tas/>[, orange path] on second line
 - stop
 - speed
    - playback speed to set to on second line (def. 1)
 - unpause
 - pause
 - fastforward / ffwd / skip / skipto
    - <skipto>[, pauseafter] on second line
 - pauseat
    - tick to pause at on second line
 - advance
 - playtxt
    - <chell / atlas script path>[, pbody script path] on second line. Paths are relative to tasserver.py.
 - entity
    - entity selector on second line
 - done
    - disconnects from server and ends script

Then put 1 on the third line instead of 0 and save to send the message.
