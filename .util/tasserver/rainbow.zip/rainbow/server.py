import socket
import struct
from enum import Enum
from typing import List
import select


class PlaybackState (Enum):
    PLAYING = 0
    PAUSED = 1
    FAST_FORWARD = 2

class EntityInfo:
    state: bool

    x: float
    y: float
    z: float

    pitch: float
    yaw: float
    roll: float

    vx: float
    vy: float
    vz: float

    """
    Compute the distance squared to the given coords.
    Be careful not to compare values for which you have given
    different input counts/types!
    """
    def dist_sq(self, x=None, y=None, z=None, yaw=None, pitch=None, roll=None, vx=None, vy=None, vz=None) -> float:
        dist = 0
        
        if x     is not None: dist += (self.x     - x    )**2
        if y     is not None: dist += (self.y     - y    )**2
        if z     is not None: dist += (self.z     - z    )**2
        if pitch is not None: dist += (self.pitch - pitch)**2
        if yaw   is not None: dist += (self.yaw   - yaw  )**2
        if roll  is not None: dist += (self.roll  - roll )**2
        if vx    is not None: dist += (self.vx    - vx   )**2
        if vy    is not None: dist += (self.vy    - vy   )**2
        if vz    is not None: dist += (self.vz    - vz   )**2

        return dist

    def __str__(self) -> str:

        res = "EntityInfo: \n"
        if self.state:
            res += f"\tpos: [{self.x}, {self.y}, {self.z}]\n"
            res += f"\tang: [{self.pitch}, {self.yaw}, {self.roll}]\n"
            res += f"\tvel: [{self.vx}, {self.vy}, {self.vz}]\n"
        else:
            res += "\tEntity not found\n"
        return res

class TasServer:

    sock: socket.socket

    # Server state
    active_scripts: List[str] = []
    state: PlaybackState
    playback_rate: float
    current_tick: int
    debug_tick: int
    game_location: str
    
    """
    Initiate a connection to the server
    """
    def connect(self, ip = "127.0.0.1", port = 6555):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.connect((ip, port))

    # =============================================================
    #                             Send
    # =============================================================

    """
    Request a playback of the given file(s)
    """
    def start_playback(self, script_path1: str, script_path2: str = ""):
        packet = b''
        packet += struct.pack("!B", 0)
        packet += struct.pack("!I", len(script_path1))
        packet += script_path1.encode()
        packet += struct.pack("!I", len(script_path2))
        packet += script_path2.encode()

        self.sock.send(packet)

    """
    Request for the playback to stop
    """
    def stop_playback(self):
        self.sock.send(struct.pack("!B", 1))

    """
    Request a change to the playback speed
    """
    def change_playback_speed(self, speed: float):
        packet = b''
        packet += struct.pack("!B", 2)
        packet += struct.pack("!f", speed)

        self.sock.send(packet)

    """
    Request for the playback to resume
    """
    def resume_playback(self):
        self.sock.send(struct.pack("!B", 3))

    """
    Request for the playback to pause
    """
    def pause_playback(self):
        self.sock.send(struct.pack("!B", 4))

    """
    Request fast-forward
    """
    def fast_forward(self, to_tick = 0, pause_after = False):
        packet = b''
        packet += struct.pack("!B", 5)
        packet += struct.pack("!I", to_tick)
        packet += struct.pack("!?", pause_after)

        self.sock.send(packet)

    """
    Request for the playback to pause at the given tick
    """
    def pause_at(self, tick = 0):
        packet = b''
        packet += struct.pack("!B", 6)
        packet += struct.pack("!I", tick)

        self.sock.send(packet)

    """
    Request for the playback to advance a single tick
    """
    def advance_playback(self):
        self.sock.send(struct.pack("!B", 7))

    """
    Request information on an entity, player is default
    """
    def entity_info(self, entity_selector = "player"):
        packet = b''
        packet += struct.pack("!B", 100)
        packet += struct.pack("!I", len(entity_selector))
        packet += entity_selector.encode()

        self.sock.send(packet)


    # =============================================================
    #                            Receive
    # =============================================================

    """
    Recieve all pending data from the server. Non blocking.
    """
    def recieve(self) -> List[EntityInfo]:
        entity_info_list = []

        # readable will contain our socket only if there is data to read
        readable, w, e = select.select([self.sock], [], [], 0)

        while len(readable) > 0:
            # read data
            msg_type = self.sock.recv(1)
            msg_type = struct.unpack("!B", msg_type)[0]

            if msg_type == 0: # Set active files
                len1 = struct.unpack("!I", self.sock.recv(4))[0]
                if len1 > 0:
                    self.active_scripts.append(str(self.sock.recv(len1)))
                len2 = struct.unpack("!I", self.sock.recv(4))[0]
                if len2 > 0:
                    self.active_scripts.append(str(self.sock.recv(len2)))
            elif msg_type == 1: # Set inactive
                self.active_scripts.clear()
            elif msg_type == 2: # Set playback rate
                self.playback_rate = struct.unpack("!f", self.sock.recv(4))[0]
            elif msg_type == 3: # Set state to playing
                self.state = PlaybackState.PLAYING
            elif msg_type == 4: # Set state to paused
                self.state = PlaybackState.PAUSED
            elif msg_type == 5: # Set state to ff
                self.state = PlaybackState.FAST_FORWARD
            elif msg_type == 6: # Set tick
                self.current_tick = struct.unpack("!I", self.sock.recv(4))[0]
            elif msg_type == 7: # Set debug tick
                self.debug_tick = struct.unpack("!i", self.sock.recv(4))[0]
            elif msg_type == 100: # Entity info
                ent_info = EntityInfo()
                info_state = struct.unpack("!B", self.sock.recv(1))[0]
                ent_info.state = info_state != 0

                if ent_info.state: # The rest of the data is present
                    ent_data = struct.unpack("!fffffffff", self.sock.recv(4*9))
                    ent_info.x = ent_data[0]
                    ent_info.y = ent_data[1]
                    ent_info.z = ent_data[2]
                    ent_info.pitch = ent_data[3]
                    ent_info.yaw = ent_data[4]
                    ent_info.roll = ent_data[5]
                    ent_info.vx = ent_data[6]
                    ent_info.vy = ent_data[7]
                    ent_info.vz = ent_data[8]
                
                entity_info_list.append(ent_info)

            elif msg_type == 255: # Game location
                str_len = struct.unpack("!I", self.sock.recv(4))[0]
                if str_len > 0:
                    self.game_location = str(self.sock.recv(str_len))
            else:
                print("Unkown message!")
            # Check if there is more data
            readable, w, e = select.select([self.sock], [], [], 0)

        return entity_info_list

    def __str__(self) -> str:
        res = "TasServer: \n"
        res += f"\tactive_scripts: {str(self.active_scripts)}\n"
        res += f"\tstate: {str(self.state)}\n"
        res += f"\tplayback_rate: {str(self.playback_rate)}\n"
        res += f"\tcurrent_tick: {str(self.current_tick)}\n"
        res += f"\tdebug_tick: {str(self.debug_tick)}\n"
        res += f"\tgame_location: {str(self.game_location)}\n"
        return res